a simple image upload using
Vuejs,Vuex,axios,Bulma,expressjs & express-fileupload 
uploaded image will be saved in server folder
